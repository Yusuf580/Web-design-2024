//Making the images about the gym and spa to move in the home page
let image = document.getElementById('image');
let images = ['Images/spa1.jpg','Images/spa2.jpg','Images/gym1.jpg','Images/gym2.jpg']
setInterval(function(){
    let random = Math.floor(Math.random() * 4);
    image.src = images[random]
},800);

//working on the popup menu in the contact section
let popup = document.getElementById("popup");

function openPopup(){
    popup.classList.add("open-popup");
}
function closePopup(){
    popup.classList.remove("open-popup");
}


