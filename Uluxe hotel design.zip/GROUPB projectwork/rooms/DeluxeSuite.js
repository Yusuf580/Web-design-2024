let index = 0;
let images = ['Deluxe1.jpg', 'Deluxe2.jpg', 'Deluxe3.jpg'];
function changeBackground(){
  let body= document.getElementById("slideshow");
   
body.style.backgroundImage ="url('" + images[index] + "')" ;
       index = (index + 1) % images.length;}
   
setInterval(changeBackground, 5000);
