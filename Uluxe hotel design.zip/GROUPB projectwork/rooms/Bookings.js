let index = 0;
let images = ['Background1.jpg', 'Background3.jpg', 'Background4.jpg', 'Executive3.jpg', 'Background2.jpg'];
function changeBackground(){
  let body= document.getElementById("slideshow-S");
   
body.style.backgroundImage ="url('" + images[index] + "')" ;
       index = (index + 1) % images.length;}
   
setInterval(changeBackground, 5000);

document.querySelector('input[type="submit"').addEventListener('click', function() {
    window.location.href = "../hotel.html"
});