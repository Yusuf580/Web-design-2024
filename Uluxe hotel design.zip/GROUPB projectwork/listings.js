        let index=0;
            let images=['downloaded/E3.jpg','downloaded/B4.jpg','downloaded/B3.avif','downloaded/D2.jpg','downloaded/E1.avif'];
            
         function changeImage(){
               let imgElement= document.getElementById("slides");
                  if(imgElement){
                      imgElement.src=images[index];
                      index=(index + 1)% images.length;
                  }
                else{
                     console.error('image element with id "slides" was not found');
                }}
               setInterval(changeImage,5000);  
              
             