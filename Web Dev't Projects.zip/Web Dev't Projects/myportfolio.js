const sections = document.querySelectorAll('.section');
const sectBtns = document.querySelectorAll('.controlls'); // Corrected class name 'controlls'
const sectBtn = document.querySelectorAll('.control');
const allSections = document.querySelector('.main-content'); // Corrected selector '.main-content'

function PageTransitions() {
    // Button click active class
    for (let i = 0; i < sectBtn.length; i++) {
        sectBtn[i].addEventListener('click', function () {
            let currentBtn = document.querySelector('.active-btn'); // Corrected selector '.active-btn'
            currentBtn.classList.remove('active-btn');
            this.classList.add('active-btn');
        });
    }
}

PageTransitions();